#!/bin/sh
# App-scoped workaround for rootful iOS setuid execution suppressing DYLD insertion.
set -u

TARGET=/Applications/GPT.app/GPT
ENGINE=/usr/lib/libsubstitute.dylib
TWEAK=/Library/MobileSubstrate/DynamicLibraries/tweakgpt.dylib
INJECTOR=/usr/bin/sinject
TIMEOUT=/usr/bin/timeout
STATE=/var/run/com.csmk.gptuk-injector.state
DISABLED=/var/run/com.csmk.gptuk-injector.disabled
LOG=/var/log/gptuk-injector.log

umask 077
last_identity=
if [ -r "$STATE" ]; then IFS= read -r last_identity < "$STATE" || :; fi
trap 'exit 0' TERM INT

log() {
    # Bound this service's log; do not log process environments or app data.
    if [ -f "$LOG" ]; then
        bytes=$(wc -c < "$LOG" 2>/dev/null || echo 0)
        if [ "$bytes" -gt 131072 ] 2>/dev/null; then
            tail -n 100 "$LOG" > "$LOG.new" && mv -f "$LOG.new" "$LOG"
        fi
    fi
    printf '%s %s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$*" >> "$LOG"
}

identity_for() {
    # Both executable path and root UID must match; a process name alone is insufficient.
    ps -p "$1" -o uid=,comm= 2>/dev/null |
        while read -r owner executable; do
            [ "$owner" = 0 ] && [ "$executable" = "$TARGET" ] && exit 0
            exit 1
        done || return 1
    started=$(ps -p "$1" -o lstart= 2>/dev/null) || return 1
    [ -n "$started" ] || return 1
    printf '%s|%s\n' "$1" "$started"
}

log 'service started'
while :; do
    if [ -e "$DISABLED" ]; then sleep 1; continue; fi
    if [ ! -r "$ENGINE" ] || [ ! -r "$TWEAK" ] ||
       [ ! -x "$INJECTOR" ] || [ ! -x "$TIMEOUT" ]; then
        sleep 2
        continue
    fi
    pid=$(ps -axo pid=,uid=,comm= 2>/dev/null |
        while read -r candidate owner executable; do
            if [ "$owner" = 0 ] && [ "$executable" = "$TARGET" ]; then
                printf '%s\n' "$candidate"
                break
            fi
        done)
    case "$pid" in ''|*[!0-9]*) sleep 1; continue ;; esac
    identity=$(identity_for "$pid") || { sleep 1; continue; }
    if [ "$identity" = "$last_identity" ]; then sleep 1; continue; fi

    # Give dyld and the app's Objective-C classes time to initialize, then recheck identity.
    sleep 1
    current=$(identity_for "$pid") || continue
    [ "$current" = "$identity" ] || continue
    last_identity=$identity
    # Record before injecting: a timeout/partial load must not cause automatic retries.
    printf '%s\n' "$identity" > "$STATE.new" && mv -f "$STATE.new" "$STATE"

    environment=$(ps eww -p "$pid" -o command= 2>/dev/null || :)
    case " $environment " in
        *' _MSSafeMode=1 '*|*' _MSSafeMode=YES '*|*' _SubstituteSafeMode=1 '*|*' _SubstituteSafeMode=YES '*|*' _SafeMode=1 '*)
            log "pid=$pid skipped: process requests no tweak injection"
            continue
            ;;
    esac
    if [ -e "$DISABLED" ]; then continue; fi

    "$TIMEOUT" 8 "$INJECTOR" "$pid" "$ENGINE" >> "$LOG" 2>&1
    result=$?
    if [ "$result" -ne 0 ]; then
        log "pid=$pid engine failed exit=$result; no retry for this process"
        continue
    fi
    current=$(identity_for "$pid") || { log "pid=$pid exited after engine load"; continue; }
    [ "$current" = "$identity" ] || continue
    "$TIMEOUT" 8 "$INJECTOR" "$pid" "$TWEAK" >> "$LOG" 2>&1
    result=$?
    if [ "$result" -eq 0 ]; then
        log "pid=$pid injected tweakgpt"
    else
        log "pid=$pid tweak failed exit=$result; no retry for this process"
    fi
done
